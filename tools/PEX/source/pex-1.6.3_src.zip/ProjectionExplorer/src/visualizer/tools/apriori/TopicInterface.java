/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package visualizer.tools.apriori;

import java.util.ArrayList;
import java.util.List;
import visualizer.graph.Vertex;

/**
 *
 * @author robertopinho
 */
public interface TopicInterface {
    
    public boolean isPart(TopicInterface topic);    //used to decide if a node is 
                                                    //to be a child of another
    public List<String> getTerms();                 // list of terms for the topic
    public ArrayList<Vertex> getRelatedVertices();  //list of documents related to the topic

}
